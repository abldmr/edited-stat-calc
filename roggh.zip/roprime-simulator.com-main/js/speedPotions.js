{ // SpeedPots
SpeedPotName = [
["Нет зелья","None"]
,["Зелье концентрации","Concentration Potion"]
,["Зелье пробуждения","Awakening Potion"]
,["Зелье бесстрашия","Berserk Potion"]
];
}
