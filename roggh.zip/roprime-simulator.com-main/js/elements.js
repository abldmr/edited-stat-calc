{ // Elements [ZokuseiOBJ]
ZokuseiOBJ = [
["нейтральных","Neutral"]
,["Вода","Water"]
,["Земля","Earth"]
,["Огонь","Fire"]
,["Ветер","Wind"]
,["Яд","Poison"]
,["Святость","Holy"]
,["Тьма","Shadow"]
,["Призрак","Ghost"]
,["нежити","Undead"]
];
}
