{ // WeaponSize Mods
weaponsize = [
	[1   ,1   ,1   ],//Bare Fist
	[1   ,0.75,0.5 ],//Dagger
	[0.75,1   ,0.75],//One-handed Sword
	[0.75,0.75,1   ],//Two-handed Sword?
	[0.75,0.75,1   ],//One-handed Spear?
	[0.75,0.75,1   ],//Two-handed Spear?
	[0.5 ,0.75,1   ],//One-handed Axe?
	[0.5 ,0.75,1   ],//Two-handed Axe?
	[0.75,1   ,1   ],//Mace
	[1   ,1   ,1   ],//Staff
	[1   ,1   ,0.75],//Bow
	[0.75,1   ,0.75],//Musical InstrumentKatar
	[1   ,1   ,0.5 ],//Book
	[1   ,1	  ,0.75],//Knuckle	old : [1   ,0.75,0.5 ]
	[0.75,1   ,0.75],//Musical Instrument
	[0.75,1   ,0.5 ],//Whip
	[0.75,0.75,1   ],//Fuuma Shuriken?
	[1   ,1   ,1   ],//Revolver?
	[1   ,1   ,1   ],//Rifle?
	[1   ,1   ,1   ],//Shotgun?
	[1   ,1   ,1   ],//Gatling Gun?
	[1   ,1   ,1   ],//Grenade Launcher?
];
}
