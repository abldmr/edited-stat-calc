{ // Races [SyuzokuOBJ]
SyuzokuOBJ = [
["бесформенных","Formless"]
,["Нежити","Undead"]
,["Животные","Brute"]
,["Растений","Plant"]
,["Насекомые","Insect"]
,["Рыбы","Fish"]
,["демонов","Demon"]
,["Человекоподобные","Demi-Human"]
,["ангелов","Angel"]
,["драконов","Dragon"]
];
}
