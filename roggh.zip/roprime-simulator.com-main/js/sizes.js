{ // Sizes
SizeOBJ = [
["маленьким","Small"]
,["средним","Medium"]
,["большим","Large"]
];
}
